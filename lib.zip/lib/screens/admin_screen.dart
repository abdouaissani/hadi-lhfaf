import 'package:flutter/material.dart';

import '../services/supabase_service.dart';
import 'barber_location_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final SupabaseService _service = SupabaseService();

  String? _barberId;

  bool _loading = true;
  bool _queueEnabled = true;
  bool _nextLoading = false;
  bool _logoutLoading = false;

  List<Map<String, dynamic>> _services = [];

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  // =========================================================
  // INITIALIZE
  // =========================================================

  Future<void> _initialize() async {
    try {
      final user = _service.currentUser;

      if (user == null) {
        if (!mounted) return;
        Navigator.of(context).pop();
        return;
      }

      _barberId = user.id;

      final enabled = await _service.isQueueEnabled(user.id);

      await _loadServices();

      if (!mounted) return;

      setState(() {
        _queueEnabled = enabled;
        _loading = false;
      });
    } catch (e) {
      debugPrint('INITIALIZE ERROR: $e');

      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      _showMessage('تعذر تحميل لوحة التحكم');
    }
  }

  // =========================================================
  // LOAD SERVICES
  // =========================================================

  Future<void> _loadServices() async {
    if (_barberId == null) return;

    try {
      final services = await _service.getAllServices(_barberId!);

      if (!mounted) return;

      setState(() {
        _services = services;
      });
    } catch (e) {
      debugPrint('LOAD SERVICES ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر تحميل الخدمات');
    }
  }

  // =========================================================
  // ADD SERVICE
  // =========================================================

  Future<void> _showAddServiceDialog() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) {
        return const _ServiceDialog(
          title: 'إضافة خدمة',
          buttonText: 'إضافة',
        );
      },
    );

    if (!mounted || result == null) return;

    final name = result['name']?.toString() ?? '';
    final price = result['price'] as double?;

    if (name.isEmpty || price == null) return;

    try {
      await _service.addService(
        barberId: _barberId!,
        name: name,
        price: price,
      );

      await _loadServices();

      if (!mounted) return;

      _showMessage('تمت إضافة الخدمة بنجاح');
    } catch (e) {
      debugPrint('ADD SERVICE ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر إضافة الخدمة');
    }
  }

  // =========================================================
  // EDIT SERVICE
  // =========================================================

  Future<void> _showEditServiceDialog(
    Map<String, dynamic> service,
  ) async {
    final id = service['id']?.toString();

    if (id == null || id.isEmpty) return;

    final oldName = service['name']?.toString() ?? '';

    final oldPrice =
        double.tryParse(service['price']?.toString() ?? '0') ?? 0;

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) {
        return _ServiceDialog(
          title: 'تعديل الخدمة',
          buttonText: 'حفظ',
          initialName: oldName,
          initialPrice: oldPrice,
        );
      },
    );

    if (!mounted || result == null) return;

    final name = result['name']?.toString() ?? '';
    final price = result['price'] as double?;

    if (name.isEmpty || price == null) return;

    try {
      await _service.updateService(
        serviceId: id,
        name: name,
        price: price,
      );

      await _loadServices();

      if (!mounted) return;

      _showMessage('تم تعديل الخدمة');
    } catch (e) {
      debugPrint('UPDATE SERVICE ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر تعديل الخدمة');
    }
  }

  // =========================================================
  // TOGGLE SERVICE
  // =========================================================

  Future<void> _toggleService(
    Map<String, dynamic> service,
    bool value,
  ) async {
    final id = service['id']?.toString();

    if (id == null || id.isEmpty) return;

    try {
      await _service.setServiceActive(
        serviceId: id,
        active: value,
      );

      await _loadServices();

      if (!mounted) return;

      _showMessage(
        value ? 'تم تفعيل الخدمة' : 'تم تعطيل الخدمة',
      );
    } catch (e) {
      debugPrint('TOGGLE SERVICE ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر تغيير حالة الخدمة');
    }
  }

  // =========================================================
  // DELETE SERVICE
  // =========================================================

  Future<void> _deleteService(
    Map<String, dynamic> service,
  ) async {
    final id = service['id']?.toString();

    if (id == null || id.isEmpty) return;

    final name = service['name']?.toString() ?? 'هذه الخدمة';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('حذف الخدمة'),
            content: Text(
              'هل أنت متأكد من حذف "$name"؟',
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop(false);
                },
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop(true);
                },
                child: const Text('حذف'),
              ),
            ],
          ),
        );
      },
    );

    if (!mounted || confirmed != true) return;

    try {
      await _service.deleteService(id);

      await _loadServices();

      if (!mounted) return;

      _showMessage('تم حذف الخدمة');
    } catch (e) {
      debugPrint('DELETE SERVICE ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر حذف الخدمة');
    }
  }

  // =========================================================
  // NEXT CUSTOMER
  // =========================================================

  Future<void> _nextCustomer() async {
    if (_barberId == null || _nextLoading) {
      return;
    }

    setState(() {
      _nextLoading = true;
    });

    try {
      final result = await _service.nextQueueTicket(
        _barberId!,
      );

      if (!mounted) return;

      final message = result['message']?.toString();

      if (message == 'NO_MORE_CUSTOMERS') {
        _showMessage('لا يوجد زبائن في الانتظار');
      } else {
        _showMessage('تم استدعاء الزبون التالي');
      }
    } catch (e) {
      debugPrint('NEXT CUSTOMER ERROR: $e');

      if (!mounted) return;

      _showMessage(
        'حدث خطأ أثناء استدعاء الدور التالي',
      );
    } finally {
      if (mounted) {
        setState(() {
          _nextLoading = false;
        });
      }
    }
  }

  // =========================================================
  // TOGGLE QUEUE
  // =========================================================

  Future<void> _toggleQueue(bool value) async {
    if (_barberId == null) return;

    final oldValue = _queueEnabled;

    setState(() {
      _queueEnabled = value;
    });

    try {
      await _service.setQueueEnabled(
        _barberId!,
        value,
      );

      if (!mounted) return;

      _showMessage(
        value
            ? 'تم فتح استقبال الحجوزات'
            : 'تم إغلاق استقبال الحجوزات',
      );
    } catch (e) {
      debugPrint('QUEUE TOGGLE ERROR: $e');

      if (!mounted) return;

      setState(() {
        _queueEnabled = oldValue;
      });

      _showMessage('تعذر تغيير حالة الحجز');
    }
  }

  // =========================================================
  // LOCATION
  // =========================================================

  Future<void> _openLocation() async {
    if (_barberId == null) return;

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BarberLocationScreen(
          barberId: _barberId!,
        ),
      ),
    );
  }

  // =========================================================
  // LOGOUT
  // =========================================================

  Future<void> _logout() async {
    if (_logoutLoading) return;

    setState(() {
      _logoutLoading = true;
    });

    try {
      await _service.barberLogout();

      if (!mounted) return;

      Navigator.of(context).pop();
    } catch (e) {
      debugPrint('LOGOUT ERROR: $e');

      if (!mounted) return;

      _showMessage('تعذر تسجيل الخروج');

      setState(() {
        _logoutLoading = false;
      });
    }
  }

  // =========================================================
  // MESSAGE
  // =========================================================

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          textAlign: TextAlign.right,
        ),
      ),
    );
  }

  // =========================================================
  // TODAY
  // =========================================================

  String _todayDate() {
    final now = DateTime.now();

    return '${now.year.toString().padLeft(4, '0')}-'
        '${now.month.toString().padLeft(2, '0')}-'
        '${now.day.toString().padLeft(2, '0')}';
  }

  // =========================================================
  // BUILD
  // =========================================================

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_barberId == null) {
      return const Scaffold(
        body: Center(
          child: Text(
            'لم يتم العثور على حساب الحلاق',
          ),
        ),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'لوحة الحلاق',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'تسجيل الخروج',
              onPressed:
                  _logoutLoading ? null : _logout,
              icon: _logoutLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(Icons.logout),
            ),
          ],
        ),
        body: StreamBuilder<List<Map<String, dynamic>>>(
          stream: _service.watchQueue(_barberId!),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      size: 60,
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      'حدث خطأ في تحميل الطابور',
                    ),
                    const SizedBox(height: 15),
                    FilledButton(
                      onPressed: () {
                        setState(() {});
                      },
                      child: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              );
            }

            if (!snapshot.hasData) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            final tickets = snapshot.data ?? [];

            final today = _todayDate();

            final todayTickets = tickets.where((ticket) {
              return ticket['queue_date']?.toString() ==
                  today;
            }).toList();

            final serving = todayTickets.where((ticket) {
              return ticket['status']?.toString() ==
                  'serving';
            }).toList();

            int currentNumber = 0;

            if (serving.isNotEmpty) {
              currentNumber =
                  int.tryParse(
                        serving.first['ticket_number']
                                ?.toString() ??
                            '',
                      ) ??
                      0;
            }

            final waiting = todayTickets.where((ticket) {
              return ticket['status']?.toString() ==
                  'waiting';
            }).toList();

            waiting.sort((a, b) {
              final aNumber =
                  int.tryParse(
                        a['ticket_number']?.toString() ??
                            '',
                      ) ??
                      0;

              final bNumber =
                  int.tryParse(
                        b['ticket_number']?.toString() ??
                            '',
                      ) ??
                      0;

              return aNumber.compareTo(bNumber);
            });

            return RefreshIndicator(
              onRefresh: () async {
                await _loadServices();

                if (mounted) {
                  setState(() {});
                }
              },
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // =================================================
                  // LOCATION
                  // =================================================

                  Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        child: Icon(
                          Icons.location_on,
                        ),
                      ),
                      title: const Text(
                        'موقع المحل',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: const Text(
                        'حدد موقع المحل على الخريطة',
                      ),
                      trailing: const Icon(
                        Icons.arrow_forward_ios,
                        size: 18,
                      ),
                      onTap: _openLocation,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // =================================================
                  // QUEUE STATUS
                  // =================================================

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: Colors.grey.shade300,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _queueEnabled
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'حالة الحجز',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                _queueEnabled
                                    ? 'استقبال الحجوزات مفتوح'
                                    : 'استقبال الحجوزات مغلق',
                                style: TextStyle(
                                  color: _queueEnabled
                                      ? Colors.green
                                      : Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: _queueEnabled,
                          onChanged: _toggleQueue,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // =================================================
                  // CURRENT NUMBER
                  // =================================================

                  Container(
                    padding: const EdgeInsets.all(25),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: Colors.grey.shade300,
                      ),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'الدور الحالي',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          currentNumber == 0
                              ? '--'
                              : '#$currentNumber',
                          style: const TextStyle(
                            fontSize: 58,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'عدد المنتظرين: ${waiting.length}',
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // =================================================
                  // NEXT BUTTON
                  // =================================================

                  SizedBox(
                    height: 60,
                    child: FilledButton.icon(
                      onPressed:
                          _nextLoading || waiting.isEmpty
                              ? null
                              : _nextCustomer,
                      icon: _nextLoading
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(
                              Icons.arrow_forward,
                            ),
                      label: Text(
                        waiting.isEmpty
                            ? 'لا يوجد دور تالٍ'
                            : 'استدعاء التالي',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // =================================================
                  // WAITING LIST
                  // =================================================

                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'قائمة الانتظار',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      CircleAvatar(
                        radius: 18,
                        child: Text(
                          '${waiting.length}',
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  if (waiting.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(30),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(18),
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                      ),
                      child: const Column(
                        children: [
                          Icon(
                            Icons.event_available_outlined,
                            size: 55,
                          ),
                          SizedBox(height: 12),
                          Text(
                            'لا يوجد زبائن في الانتظار',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ...waiting.map((ticket) {
                      final number =
                          ticket['ticket_number'];

                      final name =
                          ticket['customer_name']
                                  ?.toString() ??
                              'بدون اسم';

                      final phone =
                          ticket['phone']?.toString() ?? '';

                      return Card(
                        margin: const EdgeInsets.only(
                          bottom: 10,
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(
                              '#$number',
                              style: const TextStyle(
                                fontSize: 12,
                              ),
                            ),
                          ),
                          title: Text(
                            name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: phone.isEmpty
                              ? null
                              : Text(phone),
                          trailing: const Icon(
                            Icons.hourglass_empty,
                          ),
                        ),
                      );
                    }),

                  const SizedBox(height: 30),

                  // =================================================
                  // SERVICES
                  // =================================================

                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'الخدمات',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      FilledButton.icon(
                        onPressed:
                            _showAddServiceDialog,
                        icon: const Icon(Icons.add),
                        label: const Text('إضافة'),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  if (_services.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(25),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(18),
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                      ),
                      child: const Column(
                        children: [
                          Icon(
                            Icons.content_cut_outlined,
                            size: 50,
                          ),
                          SizedBox(height: 10),
                          Text('لا توجد خدمات'),
                        ],
                      ),
                    )
                  else
                    ..._services.map((service) {
                      final name =
                          service['name']?.toString() ??
                              'بدون اسم';

                      final price =
                          double.tryParse(
                                service['price']
                                        ?.toString() ??
                                    '0',
                              ) ??
                              0;

                      final active =
                          service['is_active'] == true;

                      return Card(
                        margin: const EdgeInsets.only(
                          bottom: 10,
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: const Icon(
                              Icons.content_cut,
                            ),
                          ),
                          title: Text(
                            name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            '${price.toStringAsFixed(0)} DA',
                          ),
                          trailing:
                              PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') {
                                _showEditServiceDialog(
                                  service,
                                );
                              }

                              if (value == 'active') {
                                _toggleService(
                                  service,
                                  !active,
                                );
                              }

                              if (value == 'delete') {
                                _deleteService(
                                  service,
                                );
                              }
                            },
                            itemBuilder: (context) {
                              return [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('تعديل'),
                                ),
                                PopupMenuItem(
                                  value: 'active',
                                  child: Text(
                                    active
                                        ? 'تعطيل'
                                        : 'تفعيل',
                                  ),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text('حذف'),
                                ),
                              ];
                            },
                          ),
                        ),
                      );
                    }),

                  const SizedBox(height: 30),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

// =============================================================
// SERVICE DIALOG
// =============================================================

class _ServiceDialog extends StatefulWidget {
  final String title;
  final String buttonText;
  final String initialName;
  final double? initialPrice;

  const _ServiceDialog({
    required this.title,
    required this.buttonText,
    this.initialName = '',
    this.initialPrice,
  });

  @override
  State<_ServiceDialog> createState() =>
      _ServiceDialogState();
}

class _ServiceDialogState extends State<_ServiceDialog> {
  late final TextEditingController _nameController;
  late final TextEditingController _priceController;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();

    _nameController = TextEditingController(
      text: widget.initialName,
    );

    _priceController = TextEditingController(
      text: widget.initialPrice == null
          ? ''
          : widget.initialPrice!
              .toStringAsFixed(0),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final price = double.tryParse(
      _priceController.text
          .trim()
          .replaceAll(',', '.'),
    );

    if (price == null || price < 0) {
      return;
    }

    Navigator.of(context).pop({
      'name': _nameController.text.trim(),
      'price': price,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(widget.title),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  textInputAction:
                      TextInputAction.next,
                  decoration: const InputDecoration(
                    labelText: 'اسم الخدمة',
                    hintText: 'مثال: قص شعر',
                    prefixIcon:
                        Icon(Icons.content_cut),
                  ),
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'أدخل اسم الخدمة';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 16),

                TextFormField(
                  controller: _priceController,
                  keyboardType:
                      const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration:
                      const InputDecoration(
                    labelText: 'السعر',
                    hintText: 'مثال: 500',
                    prefixIcon: Icon(
                      Icons.payments_outlined,
                    ),
                    suffixText: 'DA',
                  ),
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'أدخل السعر';
                    }

                    final price = double.tryParse(
                      value
                          .trim()
                          .replaceAll(',', '.'),
                    );

                    if (price == null ||
                        price < 0) {
                      return 'السعر غير صحيح';
                    }

                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: _submit,
            child: Text(widget.buttonText),
          ),
        ],
      ),
    );
  }
}