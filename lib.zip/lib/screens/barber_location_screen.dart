import 'package:flutter/material.dart';

import '../services/supabase_service.dart';

class BarberLocationScreen extends StatefulWidget {
  final String barberId;

  const BarberLocationScreen({
    super.key,
    required this.barberId,
  });

  @override
  State<BarberLocationScreen> createState() =>
      _BarberLocationScreenState();
}

class _BarberLocationScreenState
    extends State<BarberLocationScreen> {
  final SupabaseService _service = SupabaseService();

  final TextEditingController _locationController =
      TextEditingController();

  final TextEditingController _latitudeController =
      TextEditingController();

  final TextEditingController _longitudeController =
      TextEditingController();

  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  Future<void> _loadLocation() async {
    try {
      final data = await _service.getBarberLocation(
        widget.barberId,
      );

      if (!mounted) return;

      final latitude =
          (data?['latitude'] as num?)?.toDouble();
      final longitude =
          (data?['longitude'] as num?)?.toDouble();

      if (latitude != null && longitude != null) {
        _latitudeController.text =
            latitude.toString();
        _longitudeController.text =
            longitude.toString();
      }
    } catch (e) {
      if (!mounted) return;

      _showMessage(
        'تعذر تحميل موقع المحل: $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  // =========================================================
  // PARSE COPIED LOCATION
  // =========================================================

  void _pasteLocation() {
    final text = _locationController.text.trim();

    if (text.isEmpty) {
      _showMessage(
        'الصق رابط Google Maps أو الإحداثيات أولاً',
      );
      return;
    }

    // يدعم مثلاً:
    // 33.5731,-7.5898
    // 33.5731, -7.5898
    // https://www.google.com/maps/@33.5731,-7.5898,17z
    // https://maps.google.com/?q=33.5731,-7.5898
    final regex = RegExp(
      r'(-?\d+(?:\.\d+)?)\s*[,;]\s*(-?\d+(?:\.\d+)?)',
    );

    final match = regex.firstMatch(text);

    if (match == null) {
      _showMessage(
        'لم أستطع استخراج الإحداثيات من النص',
      );
      return;
    }

    final latitude =
        double.tryParse(match.group(1) ?? '');
    final longitude =
        double.tryParse(match.group(2) ?? '');

    if (!_validCoordinates(latitude, longitude)) {
      _showMessage(
        'الإحداثيات غير صحيحة',
      );
      return;
    }

    _latitudeController.text =
        latitude!.toString();
    _longitudeController.text =
        longitude!.toString();

    FocusScope.of(context).unfocus();

    _showMessage(
      'تم استخراج الموقع بنجاح 📍',
    );
  }

  bool _validCoordinates(
    double? latitude,
    double? longitude,
  ) {
    if (latitude == null || longitude == null) {
      return false;
    }

    return latitude >= -90 &&
        latitude <= 90 &&
        longitude >= -180 &&
        longitude <= 180;
  }

  // =========================================================
  // SAVE
  // =========================================================

  Future<void> _saveLocation() async {
    if (_saving) return;

    final latitude = double.tryParse(
      _latitudeController.text.trim().replaceAll(',', '.'),
    );

    final longitude = double.tryParse(
      _longitudeController.text.trim().replaceAll(',', '.'),
    );

    if (!_validCoordinates(latitude, longitude)) {
      _showMessage(
        'أدخل إحداثيات صحيحة: خط العرض وخط الطول',
      );
      return;
    }

    FocusScope.of(context).unfocus();

    setState(() {
      _saving = true;
    });

    try {
      await _service.updateBarberLocation(
        barberId: widget.barberId,
        latitude: latitude!,
        longitude: longitude!,
      );

      if (!mounted) return;

      _showMessage(
        'تم حفظ موقع المحل بنجاح 📍',
      );
    } catch (e) {
      if (!mounted) return;

      _showMessage(
        'تعذر حفظ الموقع: $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .hideCurrentSnackBar();

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          message,
          textAlign: TextAlign.right,
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _locationController.dispose();
    _latitudeController.dispose();
    _longitudeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'موقع المحل 📍',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
        ),
        body: _loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(18),
                        color: Theme.of(context)
                            .colorScheme
                            .surfaceContainerHighest,
                      ),
                      child: const Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.location_on),
                              SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'أدخل موقع المحل يدوياً',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Text(
                            'يمكنك نسخ رابط Google Maps ولصقه هنا، أو إدخال خط العرض وخط الطول مباشرة.',
                            style: TextStyle(
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    TextField(
                      controller: _locationController,
                      maxLines: 3,
                      textDirection: TextDirection.ltr,
                      decoration: InputDecoration(
                        labelText:
                            'الصق رابط Google Maps أو الإحداثيات',
                        hintText:
                            'مثال: 33.5731,-7.5898',
                        prefixIcon: const Icon(
                          Icons.content_paste,
                        ),
                        suffixIcon: IconButton(
                          tooltip: 'استخراج الإحداثيات',
                          onPressed: _pasteLocation,
                          icon: const Icon(
                            Icons.location_searching,
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(14),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    OutlinedButton.icon(
                      onPressed: _pasteLocation,
                      icon: const Icon(
                        Icons.my_location,
                      ),
                      label: const Text(
                        'استخراج الإحداثيات من النص',
                      ),
                    ),

                    const SizedBox(height: 25),

                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller:
                                _latitudeController,
                            keyboardType:
                                const TextInputType.numberWithOptions(
                              decimal: true,
                              signed: true,
                            ),
                            textDirection:
                                TextDirection.ltr,
                            decoration:
                                InputDecoration(
                              labelText: 'خط العرض Latitude',
                              hintText: '33.5731',
                              prefixIcon: const Icon(
                                Icons.north,
                              ),
                              border:
                                  OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller:
                                _longitudeController,
                            keyboardType:
                                const TextInputType.numberWithOptions(
                              decimal: true,
                              signed: true,
                            ),
                            textDirection:
                                TextDirection.ltr,
                            decoration:
                                InputDecoration(
                              labelText: 'خط الطول Longitude',
                              hintText: '-7.5898',
                              prefixIcon: const Icon(
                                Icons.east,
                              ),
                              border:
                                  OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 25),

                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(14),
                        border: Border.all(
                          color: Colors.grey.shade300,
                        ),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.info_outline,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'إذا نسخت رابطاً من Google Maps، الصقه في الخانة الأولى ثم اضغط استخراج الإحداثيات.',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),

                    SizedBox(
                      height: 56,
                      child: FilledButton.icon(
                        onPressed:
                            _saving ? null : _saveLocation,
                        icon: _saving
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.save_outlined,
                              ),
                        label: Text(
                          _saving
                              ? 'جاري الحفظ...'
                              : 'حفظ موقع المحل',
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
